'use strict';
var RSVP = require('rsvp');

var supportedVideoTypes = [ // in order of priority
  'video/webm',
  'video/mp4',
  'video/ogg'
]

var DCVideoPlayer = function () {
  
  var _videoElement = null;
  var _sourceElement = null;
  var _videoId = null;
  var _resolve = null;
  var _reject = null;
  var _container = null;

  var api = {
    get duration() {
      return player.duration;
    },
    get currentTime() {
      return player.currentTime;
    },
    get elem() {
      return _videoElement;
    }
  };

  var defaults = {
    autoplay: true
  }

  api.players = [];

  api.loadVideo = function (container, videos, id, options) { // eventually options would be good.
    console.log('load viiiiiideoooo');
    return new RSVP.Promise(function (resolve, reject) {

      _resolve = resolve;
      _reject = reject;
      _container = container;
      _videoId = id || 'video' + new Date().getTime();

      if(!container) {
        console.log('DCVideoPlayer - ', _videoId, ': Video Player Container Missing');
        _reject('DCVideoPlayer - ', _videoId, ': Video Player Container Missing');
      }
      
      _videoElement = document.createElement('video');
      _sourceElement = document.createElement('source');

      window.player = api;
      
      var multipleVideos = typeof videos == 'object';
      var supportedType = api.getVideoType(_videoElement);
      var supportedExtention = '.' + supportedType.split('/')[1];
      _videoElement.autoplay = options ? options.autoplay : defaults.autoplay;
      player = _videoElement;

      var videoUrl = null;

      if(multipleVideos) { // did we get an array of videos? lets get the one that best suits the current browser.
        for(var v in videos){
          videoUrl = videos[v];
          
          if(videoUrl.indexOf(supportedExtention) > -1) break;
        }
        
      } else { // only one video was provided. lets compare it to all supported video types.
        videoUrl = videos;
        for(var t in supportedVideoTypes){
          var type = supportedType[t];
          var extention = '.' + type.split('/')[1];

          supportedType = type;

          if(videoUrl.indexOf(extention) != -1) break;
        }
        console.error('DCVideoPlayer -', _videoId, ': No supported video provided.')
      }

      _sourceElement.src = Enabler.getUrl(videoUrl);
      _sourceElement.type = supportedType;

      var data = {
        id: _videoId,
        container: _container,
        element: _videoElement,
        source: _sourceElement,
        resolve: _resolve,
        reject: _reject
      };

      api.players.push(data);
      console.log('players',api.players);

      Enabler.loadModule(studio.module.ModuleId.VIDEO, api.initPlayer.bind(data)); // load tracking module before the video is added to the dom to avoid race condition.
    });
  };

  api.initPlayer = function (){
    studio.video.Reporter.attach(this.id, this.element);
    this.element.appendChild(this.source);
    this.container.appendChild(this.element); // lets append the container after the DC module is loaded. there's a tiny chance the module would load AFTER the video is ready to play.
    this.element.style.opacity = 0;
    this.element.addEventListener('canplaythrough', function(){
      console.log('asd?safsdklfd');
      this.element.style.opacity = 1;
      this.resolve('DCVideoPlayer -', this.id, ': Load Promise');
    }.bind(this));
  }

  api.destroy = function(element){
    console.log('destroy', element, api);
    var target = null;
    var id = null;
    var players = api.players;
    console.log('PLAYERS',players)
    if(typeof element == 'object'){
      for(var i in players){
        var player = players[i];
        if(player.element == element) {
          id = player.id;
          target = element;
          //p = player;
          console.log('player',player);
        }
        //players[i] = null;
        //players.splice(i,1);
      }
    } else {
      for(var i in players){
        var player = players[i];
        if(player.id == element) {
          target = player.element;
          id = player.id;
          //p = player;
          console.log('player',player);
        }
        //players[i] = null;
        //players.splice(i,1);
      }
    }
    console.log('hm', target, id, players);
    if(target) { target.parentNode.removeChild(target); }
    console.log('DCVideoPlayer -', id, ': destroyed');

    studio.video.Reporter.detach(id);
  }

  api.addEventListener = function(type, handler, options){
    player.addEventListener(type, handler, options);
  }

  api.removeEventListener = function(type, handler){
    player.removeEventListener(type, handler);
  }

  api.play = function(){
    player.play();
  }

  api.stop = function(){
    player.pause();
    player.currentTime = 0;
  }

  api.seek = function(time) {
    player.currentTime = time;
  }

  api.getVideoType = function(player){
    for(var t in supportedVideoTypes) {
      var type = supportedVideoTypes[t];

      if(player.canPlayType(type)){
        return type;
      }
    }
  };

  return api;
};


module.exports = DCVideoPlayer;