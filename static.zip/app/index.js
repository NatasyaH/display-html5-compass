'use strict';


console.log ("hello world");

var App = require ('./App');

window.app = new App (window.adConfig);

window.app.init();