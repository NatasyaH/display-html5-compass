FT.manifest({
  "filename": "index.html",
  "width": 970,
  "height": 250,
  "clickTagCount": 2,
  "hideBrowsers": ["ie9"],
  "expand":{
    "width": 970,
    "height": 500,
    "indentAcross": 0,
    "indentDown": 0
  },
  "richLoads": [{
  		"name": "rich",
  		"src": "RICH-NAME"
  	}]
});
